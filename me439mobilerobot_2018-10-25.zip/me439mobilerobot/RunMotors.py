#!/usr/bin/env python


from pololu_drv8835_rpi import motors

motors.motor1.setSpeed(92)
motors.motor2.setSpeed(92)
